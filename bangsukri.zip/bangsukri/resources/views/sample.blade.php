@extends('template.default')

@section('content')
    @include('template.components.content')
@endsection