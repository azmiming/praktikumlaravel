<div class="row">
                    <div class="col">
                        <h3>Bagian</h3>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col">
                        <table class="table bg-white rounded shadow-sm  table-hover">
                            <thead>
                                <tr>
                                    <th scope="col" width="50">#</th>
                                    <th scope="col">Bagian</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="align-middle">
                                    <th scope="row">1</th>
                                    <td>HRD</td>
                                </tr>
                                <tr class="align-middle">
                                    <th scope="row">2</th>
                                    <td>Finance</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
<?php /**PATH C:\Users\User\bangsukri\resources\views/template/components/content.blade.php ENDPATH**/ ?>