<a href="<?php echo e(route('ruang.edit', $ruang)); ?>" class="btn btn-primary btn-sm">
    <i class="fa fa-edit"></i>
</a>
<button class="btn btn-danger btn-sm"
onclick="confirmation(`<?php echo e(route(
'ruang.destroy', $ruang)); ?>`)">
    <i class="fa fa-trash"></i>
</button><?php /**PATH C:\Users\User\bangsukri\resources\views/ruang/action.blade.php ENDPATH**/ ?>