<a href="<?php echo e(route('karyawan.edit',$karyawan )); ?>" class="btn btn-primary btn-sm">
    <i class="fa fa-edit"></i>
</a>
<button class="btn btn-danger btn-sm"
onclick="confirmation('<?php echo e(route(
'karyawan.destroy', $karyawan)); ?>')">
    <i class="fa fa-trash"></i>
</button><?php /**PATH C:\Users\User\bangsukri\resources\views/karyawan/action.blade.php ENDPATH**/ ?>